"""CAD-derived GLB models and aligned red/blue copper overlay for the report.
Bodies are approximate envelopes; routing, pads and filled ground polygons come from KiCad.
"""
from pathlib import Path
import json,base64,struct,math,argparse
ap=argparse.ArgumentParser();ap.add_argument("--overlay-only",action="store_true");args=ap.parse_args()
from collections import defaultdict
import numpy as np,pyvista as pv
from shapely.geometry import Polygon as SPolygon
from shapely import constrained_delaunay_triangles
P=Path(__file__).resolve().parents[1];R=P/'results';g=json.loads((R/'board_geometry.json').read_text());ant=json.loads((P/'hardware/antenna_868_fr4.json').read_text())
# glTF exporter writes embedded buffers. Consolidate them into one standard GLB buffer.
def glb(src,dst):
 d=json.loads(src.read_text());blob=bytearray();offset=[]
 for b in d['buffers']:
  while len(blob)%4:blob.append(0)
  offset.append(len(blob));blob+=base64.b64decode(b['uri'].split(',',1)[1])
 for v in d['bufferViews']:v['byteOffset']=v.get('byteOffset',0)+offset[v['buffer']];v['buffer']=0
 d['buffers']=[{'byteLength':len(blob)}]
 # Input CAD coordinates are millimetres; glTF uses metres.
 for scene in d['scenes']:
  root=len(d['nodes']);d['nodes'].append({'name':'CAD millimetres to metres','scale':[.001,.001,.001],'children':scene['nodes']});scene['nodes']=[root]
 for m in d.get('materials',[]):
  pbr=m.setdefault('pbrMetallicRoughness',{});pbr['metallicFactor']=.18;pbr['roughnessFactor']=.62;m['doubleSided']=True
  rgba=pbr.get('baseColorFactor',[1,1,1,1]);pbr['baseColorFactor']=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgba[:3]]+[rgba[3]]
 d['asset']['extras']={'description':'KiCad-derived copper and placement; simplified component envelopes. Coax routing is illustrative.'}
 enc=json.dumps(d,separators=(',',':')).encode();enc+=b' '*((-len(enc))%4);blob+=b'\0'*((-len(blob))%4)
 dst.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(enc)+8+len(blob))+struct.pack('<II',len(enc),0x4E4F534A)+enc+struct.pack('<II',len(blob),0x004E4942)+blob)
 src.unlink();return len(d.get('meshes',[]))

def build(assembly=False):
 groups=defaultdict(list)
 def add(mesh,color):groups[color].append(mesh.triangulate())
 def box(x,y,z,w,h,d,color):add(pv.Cube(center=(x,y,z),x_length=w,y_length=h,z_length=d),color)
 def flat(coords,z,color,holes=None):
  poly=SPolygon(coords,holes or []).buffer(0)
  triangles=list(constrained_delaunay_triangles(poly).geoms)
  assert abs(sum(t.area for t in triangles)-poly.area)<1e-6, 'Incomplete copper triangulation'
  for t in triangles:
   xy=np.array(t.exterior.coords)[:3];add(pv.PolyData(np.c_[xy,np.full(3,z)],[3,0,1,2]),color)
 def disk(x,y,z,r,inner,color):add(pv.Disc(center=(x,y,z),inner=inner,outer=r,normal=(0,0,1),c_res=20),color)
 box(37.5,19,.8,75,38,1.6,'#155d47')
 for zone in g['zones']:flat(zone['outline'],1.616 if zone['layer']=='top' else -.016,'#287e61',zone['holes'])
 for t in g['tracks']:
  z=1.635 if t['layer']=='top' else -.035;a=np.r_[t['start'],z];b=np.r_[t['end'],z]
  if np.linalg.norm(a-b)>.001:add(pv.Line(a,b).tube(radius=t['width']/2,n_sides=6),'#baaa6b')
 for pad in g['pads']:
  x,y=pad['xy'];w,h=pad['size'];angle=np.deg2rad(pad['rotation']);rot=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])
  for layer in pad['layers']:
   z=1.72 if layer=='top' else -.072
   if pad['shape']==0:disk(x,y,z,w/2,0,'#cbd3d3')
   else:flat(np.array([[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]])@rot.T+[x,y],z,'#cbd3d3')
   if pad['drill'][0]>0:disk(x,y,z+(.008 if layer=='top' else -.008),pad['drill'][0]/2,0,'#142921')
 for c in g['parts']:
  ref=c['ref'];x,y=c['xy'];fp=c['footprint'];color='#252e37';w,h,z=1.6,.8,.7
  if ref=='U4':w,h,z=10.5,15.5,2.2;color='#bdc7cb'
  elif ref=='U3':w,h,z=3.25,3.,1.06
  elif ref=='U1':w,h,z=3,3,.9
  elif ref=='U2':w,h,z=2.9,2.8,1.1
  elif ref=='L2':w,h,z=4,4,1.8
  elif ref.startswith('TP'):continue
  elif ref.startswith('C'):
   color='#c5ab84'
   if '1210' in fp:w,h,z=2.5,3.2,2.5
  elif ref.startswith('D'):w,h,z=1.2,.8,.6
  elif ref.startswith('J'):
   if ref=='J1':w,h,z=3,3,1.25;color='#c3b16c'
   else:
    for i in range(5 if ref=='J2' else 2):box(x,y+i*2.54,2.5,2,2,1.7,'#252e37');box(x,y+i*2.54,4,.6,.6,3,'#c3b16c')
    continue
  box(x,y,1.72+z/2,w,h,z,color)
  if ref=='U4':box(x,y-5.7,4,7.5,3,1,'#277896')
 for v in g['vias']:
  x,y=v['xy']
  for z in [1.74,-.074]:
   disk(x,y,z,v['diameter']/2,v['drill']/2,'#c3b16c');disk(x,y,z,v['drill']/2,0,'#142921')
 if assembly:
  ox,oy=-22.5,55;aw,ah,az=ant['width'],ant['height'],ant['thickness'];box(ox+aw/2,oy+ah/2,az/2,aw,ah,az,'#155d47')
  flat((np.array([aw,ah])-np.array(ant['patch_polygon']))+[ox,oy],az+.04,'#d4b978')
  flat([[ox+.25,oy+.25],[ox+aw-.25,oy+.25],[ox+aw-.25,oy+ah-.25],[ox+.25,oy+ah-.25]],-.016,'#287e61')
  path=np.array([[6,8,3],[4,20,5],[5,37,6],[8,49,6],[ox+aw/2,oy+6,az+1.4]])
  add(pv.Spline(path,100).tube(radius=.6),'#141922')
 p=pv.Plotter(off_screen=True,window_size=(1400,1000));p.set_background('#101c2b')
 for color,meshes in groups.items():p.add_mesh(pv.merge(meshes,merge_points=False),color=color,smooth_shading=False)
 p.camera.parallel_projection=True
 if assembly:p.camera_position=[(175,-145,280),(37,85,0),(0,0,1)];p.camera.parallel_scale=105
 else:p.camera_position=[(105,-85,135),(37.5,19,1),(0,0,1)];p.camera.parallel_scale=45
 name='assembly_868' if assembly else 'electronics_868'
 path=R/(name+'.gltf');p.export_gltf(path,inline_data=True);meshes=glb(path,R/(name+'.glb'))
 p.enable_anti_aliasing('ssaa');p.show(screenshot=str(R/(name+'_poster.png')))
 return dict(file=name+'.glb',bytes=(R/(name+'.glb')).stat().st_size,meshes=meshes)

# Exact shared XY coordinates: bottom copper is NOT mirrored in this top-view overlay.
import xml.etree.ElementTree as ET
S='http://www.w3.org/2000/svg';ET.register_namespace('',S)
svg=ET.Element('{'+S+'}svg',{'viewBox':'-4 -8 83 52','width':'1494','height':'936','role':'img','aria-label':'Совмещённые слои PCB: верхний красный, нижний синий, вид сверху'})
def draw(tag,**attrs):return ET.SubElement(svg,'{'+S+'}'+tag,{k.replace('_','-'):str(v) for k,v in attrs.items()})
def text(x,y,value,**attrs):e=draw('text',x=x,y=y,**attrs);e.text=value
red='#ce3547';blue='#2868cc'
draw('rect',x=-4,y=-8,width=83,height=52,fill='#fffef9');draw('rect',x=0,y=0,width=75,height=38,fill='#fafbf7',stroke='#6d7e73',stroke_width=.18)
text(0,-4.9,'РАЗВОДКА · ВИД СВЕРХУ',font_family='sans-serif',font_size=1.65,fill='#203b31',font_weight='bold')
draw('circle',cx=.5,cy=-2.4,r=.45,fill=red);draw('circle',cx=20.5,cy=-2.4,r=.45,fill=blue)
text(1.6,-2,'F.Cu — верх',font_family='sans-serif',font_size=1.2,fill=red);text(21.6,-2,'B.Cu — низ',font_family='sans-serif',font_size=1.2,fill=blue);text(75,-2,'75 × 38 мм',font_family='sans-serif',font_size=1.2,fill='#586864',text_anchor='end')
for zone in g['zones']:
 paths=[]
 for ring in [zone['outline']]+zone['holes']:paths.append('M'+' L'.join(f'{x:.4f},{y:.4f}' for x,y in ring)+' Z')
 draw('path',d=' '.join(paths),fill=blue if zone['layer']=='bottom' else red,fill_opacity=.13,fill_rule='evenodd')
for layer,color in [('bottom',blue),('top',red)]:
 for t in g['tracks']:
  if t['layer']==layer:draw('line',x1=t['start'][0],y1=t['start'][1],x2=t['end'][0],y2=t['end'][1],stroke=color,stroke_width=t['width'],stroke_linecap='round',opacity=.86)
 for pad in g['pads']:
  if layer not in pad['layers']:continue
  x,y=pad['xy'];w,h=pad['size']
  if pad['shape']==0:draw('circle',cx=x,cy=y,r=w/2,fill=color,fill_opacity=.68)
  else:draw('rect',x=x-w/2,y=y-h/2,width=w,height=h,rx=pad['round_radius'],fill=color,fill_opacity=.68,transform=f'rotate({pad["rotation"]} {x} {y})')
for v in g['vias']:
 x,y=v['xy'];draw('circle',cx=x,cy=y,r=v['diameter']/2,fill='#7550a6');draw('circle',cx=x,cy=y,r=v['drill']/2,fill='#fffef9')
for pad in g['pads']:
 if pad['drill'][0]>0:draw('circle',cx=pad['xy'][0],cy=pad['xy'][1],r=pad['drill'][0]/2,fill='#fffef9')
for part in g['parts']:
 x,y=part['xy'];text(x,y,part['ref'],font_family='sans-serif',font_size=.85,text_anchor='middle',dominant_baseline='central',fill='#21332d',stroke='#fffef9',stroke_width=.16)
 text(x,y,part['ref'],font_family='sans-serif',font_size=.85,text_anchor='middle',dominant_baseline='central',fill='#21332d')
text(0,41,'Нижний слой не зеркалирован. Бледным синим показана заливка земли.',font_family='sans-serif',font_size=1.15,fill='#586864')
ET.ElementTree(svg).write(R/'pcb_combined.svg',encoding='utf-8',xml_declaration=True)
import cairosvg
cairosvg.svg2png(url=str(R/'pcb_combined.svg'),write_to=str(R/'pcb_combined.png'),output_width=1800)
if args.overlay_only:raise SystemExit(0)
results=[build(False),build(True)];(R/'interactive_models.json').write_text(json.dumps(dict(models=results,source='KiCad exported pads, routed tracks, filled copper polygons and placements',limitations='Simplified component bodies and cable; holes indicated visually, not full mechanical drill booleans; no vendor STEP models.'),indent=2));print(results)
