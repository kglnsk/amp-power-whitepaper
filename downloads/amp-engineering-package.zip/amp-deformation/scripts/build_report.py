"""Build the static white paper and self-contained downloadable research package."""
from pathlib import Path
import json,shutil,zipfile,hashlib,platform,subprocess,datetime,importlib.metadata
from jinja2 import Environment,FileSystemLoader,select_autoescape
from PIL import Image
P=Path(__file__).resolve().parents[1];R=P/'results';T=P/'report';OUT=T/'dist';OUT.mkdir(exist_ok=True)
load=lambda name:json.loads((R/(name+'.json')).read_text())
checks=load('fr4_868_checks');f=checks['fr4_868_final'];body=checks['fr4_868_body'];budget=load('budget_fr4_868')['scenarios'];normal=next(r for r in budget if r['mode']=='free' and r['distance_m']==1 and r['eirp_dBm']==30 and r['duty']==.9)
root=P.parents[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
versions={}
for name in ['numpy','scipy','matplotlib','pyvista','vtk','gmsh','jinja2']:
 try:versions[name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError:pass
env=dict(generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=platform.python_version(),packages=versions,emerge_commit=git('rev-parse','HEAD'),emerge_branch=git('branch','--show-current'),source_fingerprints={})
for rel in ['src/emerge/_emerge/physics/microwave/microwave_data.py','src/emerge/_emerge/physics/microwave/assembly/periodicbc.py']:
 env['source_fingerprints'][rel]=hashlib.sha256((root/rel).read_bytes()).hexdigest()
env['notes']='EMerge was run from the existing workspace with local modifications in the fingerprinted files. Unrelated pre-existing source edits were not committed by this task. KiCad 7.0.11, ngspice 42. FEM output is simulated, not measured.'
(R/'environment.json').write_text(json.dumps(env,indent=2))
excluded={'sc79.png','router_screen.png'}
sources=[]
for folder in ['hardware','scripts','results']:
 for p in (P/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.kicad_prl','.lck'] and p.name not in excluded:sources.append(p)
for name in ['README.md','COTS_868.md','FR4_868.md','Ambient power.jpeg','request.txt']:
 if (P/name).exists():sources.append(P/name)
sources+=list((P/'sources').glob('*.png'))
sources+=[p for p in T.iterdir() if p.is_file() and not p.name.startswith('preview-')]
files=[]
if (OUT/'files').exists():shutil.rmtree(OUT/'files')
for p in sorted(sources):
 rel=p.relative_to(P);dest=OUT/'files'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);files.append(dict(path=str(rel),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(OUT/'downloads').mkdir(exist_ok=True)
for name,filter_ in [('amp-engineering-package.zip',lambda p:True),('hardware.zip',lambda p:p['path'].startswith('hardware/'))]:
 with zipfile.ZipFile(OUT/'downloads'/name,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for entry in files:
   if filter_(entry):z.write(OUT/'files'/entry['path'],'amp-deformation/'+entry['path'])
for name in ['style.css','app.js','favicon.svg']:shutil.copyfile(T/name,OUT/name)
(OUT/'assets').mkdir(exist_ok=True)
for source,dest,size in [(P/'Ambient power.jpeg','demo.webp',1000),(P/'sources/antenna_dimensions_annotated.png','dimensions.webp',1400),(R/'schematic_868.png','schematic_868.webp',2200)]:
 im=Image.open(source).convert('RGB');im.thumbnail((size,size));im.save(OUT/'assets'/dest,quality=88)
labels=[('fr4_868_final','Свободное пространство · 0,14','Сетка 0,14'),('fr4_868_refined','Свободное пространство · 0,17','Сетка 0,17'),('fr4_868_body','Фантом · зазор 10 мм','Фантом'),('fr4_868_boundary','Граница · запас 140 мм','Область 140')]
s11=[]
for name,label,short in labels:
 d=load(name);s11.append(dict(label=label,short=short,f=[round(x/1e6,4) for x in d['frequency_hz']],db=d['s11_db']))
report_data=dict(files=files,s11=s11,curves=load('web_curves'),antennas=dict(fr4=dict(mhz=868,gain=f['peak_realized_gain_dBi'],curve='868'),body=dict(mhz=868,gain=body['peak_realized_gain_dBi'],curve='868'),cots=dict(mhz=868,gain=2.17,curve='868'),compact=dict(mhz=2450,gain=3,curve='2450')))
(OUT/'report-data.js').write_text('window.REPORT_DATA='+json.dumps(report_data,ensure_ascii=False)+';\n');(OUT/'manifest.json').write_text(json.dumps(files,indent=2,ensure_ascii=False))
fmt=lambda v,n=1:f'{v:.{n}f}'.replace('.',',')
rows=[]
for eirp in [20,30,36]:
 rr=next(r for r in budget if r['mode']=='free' and r['distance_m']==1 and r['eirp_dBm']==eirp and r['duty']==.9)
 rows.append(dict(label=f'FR4, 868 МГц · EIRP {eirp} dBm',conditions=('Duty 90%; потери 6 dB; RF выше диапазона модели, DC ограничена последней точкой' if rr['curve_clamped'] else 'Duty 90%; другие потери 6 dB'),power=fmt(rr['stored_uW'],2),cycle=fmt(rr['feature_cycle_s'],0)+' с' if rr['feature_cycle_s'] else 'Не поддерживается'))
base=load('budget')['scenarios']
for name in ['WiFi busy','WPT 2.45GHz 1W EIRP']:
 rr=next(r for r in base if r['scenario']==name and r['distance_m']==1)
 rows.append(dict(label='Wi-Fi 2,45 ГГц · EIRP 20 dBm' if name=='WiFi busy' else 'WPT 2,45 ГГц · EIRP 30 dBm',conditions='Duty 50%; другие потери 6 dB' if name=='WiFi busy' else 'Duty 90%; другие потери 6 dB',power=fmt(rr['storage_average_uW'],3),cycle=fmt(rr['feature_cycle_s'],0)+' с' if rr['feature_cycle_s'] else 'Не поддерживается'))
context=dict(gain=fmt(f['peak_realized_gain_dBi'],2),efficiency=fmt(f['radiation_efficiency_estimate']*100,0),body_gain=fmt(body['peak_realized_gain_dBi'],2),body_s11=fmt(body['s11_868_db']),s11=fmt(f['s11_868_db']),mesh_complex=fmt(checks['mesh_max_complex_s11_difference'],4),stored=fmt(normal['stored_uW']),cycle=fmt(normal['feature_cycle_s'],0),zip_mb=fmt((OUT/'downloads/amp-engineering-package.zip').stat().st_size/1048576),hw_mb=fmt((OUT/'downloads/hardware.zip').stat().st_size/1048576),scenario_rows=rows)
e=Environment(loader=FileSystemLoader(str(T)),autoescape=select_autoescape(default=True));(OUT/'index.html').write_text(e.get_template('index.html.j2').render(**context));(OUT/'.nojekyll').touch()
print(json.dumps(dict(output=str(OUT),files=len(files),context=context),indent=2,ensure_ascii=False))
