"""868 MHz COTS sensitivity study; antenna gains are assumptions on the final ground plane."""
from pathlib import Path
import json,math,csv
import numpy as np
R=Path(__file__).resolve().parents[1]/'results';base=json.loads((R/'budget.json').read_text());curve=json.loads((R/'rectifier_868/sweep.json').read_text());grid=sorted({x['dbm'] for x in curve});power=[max(0,max(x['pdc_W'] for x in curve if x['dbm']==d)) for d in grid];cold=[max(0,next(x['pdc_W'] for x in curve if x['dbm']==d and x['V']==.7)) for d in grid];rows=[]
for gain,label in [(2.17,'Taoglas reference 70mm ground'),(0.,'49mm ground assumed 0dBi'),(-3.,'49mm ground pessimistic -3dBi')]:
 for pol in [0,3]:
  for eirp in [20,30,36]:
   for distance in [.5,1,3]:
    fspl=20*math.log10(4*math.pi*distance*868e6/299792458);rf=eirp+gain-fspl-6-pol;dc=float(np.interp(rf,grid,power,left=0));stored=dc*.9*.7*.7;net=stored-2.5e-6;cs=float(np.interp(rf,grid,cold,left=0))*.9
    rows.append(dict(antenna_case=label,gain_dBi=gain,extra_polarization_loss_dB=pol,other_loss_dB=6,eirp_dBm=eirp,duty=.9,distance_m=distance,rf_on_dBm=rf,stored_uW=stored*1e6,net_uW=net*1e6,feature_cycle_s=max(20,.00092/net) if net>0 else None,cold_power_screen=cs>=15e-6,curve_clamped=rf>grid[-1]))
summary=dict(frequency_MHz=868,matching_L_nH=68,matching_shunt_parasitic_pF=.1,notes='Separate 868 MHz SPICE run. COTS antenna not FEM simulated. 70mm vendor gain not guaranteed on 49mm board. Extra 3dB polarization loss is ideal CP-to-linear case. 6dB other loss excludes that term. 90% duty is an assumed lab waveform, not band permission.',scenarios=rows)
(R/'budget_868.json').write_text(json.dumps(summary,indent=2))
with (R/'budget_868.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
for x in rows:
 if x['distance_m']==1 and x['eirp_dBm']==30:print(x)
