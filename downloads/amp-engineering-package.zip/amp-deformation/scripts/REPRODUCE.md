# Воспроизведение

Новый FR4-вариант 868 МГц и HTML-отчёт: см. `../FR4_868.md`. После основной генерации CAD запускается `make_868_variant.py`, создающий отдельную папку `hardware/868/` с номиналом L1=68 нГн.

Команды запускаются из корня репозитория EMerge. Итоговые CAD-файлы уже готовы: для их открытия генераторы запускать не требуется.

Окружение расчёта: Python 3.13 с зависимостями проекта EMerge (gmsh, numpy/scipy, Pardiso, matplotlib), ngspice 42, KiCad 7.0.11. Python KiCad в этом окружении — `/usr/bin/python3`, Python EMerge — `python` из conda. Для 3D дополнительно PyVista/VTK и рабочий OpenGL/EGL/OSMesa. `PYTHONPATH=src` нужен, чтобы использовать текущий исходный код EMerge, а не установленную старую версию.

## Пересчёт без изменения PCB

```bash
PYTHONPATH=src MKL_THREADING_LAYER=GNU python examples/amp-deformation/scripts/antenna.py --band 2450 --compact --length 28.6 --resolution .14 --points 21 --tag compact_final
PYTHONPATH=src MKL_THREADING_LAYER=GNU python examples/amp-deformation/scripts/antenna.py --band 2450 --compact --length 28.6 --resolution .17 --points 21 --tag compact_mesh_check
PYTHONPATH=src MKL_THREADING_LAYER=GNU python examples/amp-deformation/scripts/antenna.py --band 2450 --compact --length 28.6 --resolution .17 --points 21 --body --tag compact_body
python examples/amp-deformation/scripts/check_results.py
python examples/amp-deformation/scripts/rectifier.py
python examples/amp-deformation/scripts/rectifier.py --freq 915e6 --folder rectifier_915
python examples/amp-deformation/scripts/rectifier.py --freq 868e6 --folder rectifier_868
python examples/amp-deformation/scripts/budget.py
python examples/amp-deformation/scripts/budget_868.py
```

`rectifier.py` использует ngspice из PATH или локальный `.tools/ngspice/usr/bin/ngspice`. Локальные бинарные инструменты не входят в переносимый проект; в другом окружении установите ngspice отдельно. Все `.cir` и журналы остаются в папке результатов. Частота 915 МГц — отдельный исследовательский вариант, не масштабная модель исходной фотографии.

## Проверка существующей платы

```bash
kicad-cli sch export netlist --format kicadxml -o examples/amp-deformation/hardware/amp_sensor.net examples/amp-deformation/hardware/amp_sensor.kicad_sch
/usr/bin/python3 examples/amp-deformation/scripts/export_geometry.py
/usr/bin/python3 examples/amp-deformation/scripts/validate_pcb.py
python examples/amp-deformation/scripts/render.py
python examples/amp-deformation/scripts/render3d.py
```

В текущей headless-среде для последней команды потребовалось:

```bash
LD_LIBRARY_PATH="$PWD/.render-runtime/local/usr/lib/x86_64-linux-gnu" LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 VTK_DEFAULT_OPENGL_WINDOW=vtkOSOpenGLRenderWindow python examples/amp-deformation/scripts/render3d.py
```

Это локальный способ выбрать OSMesa, а не обязательная настройка на обычной рабочей станции с GUI.

## Полная регенерация CAD

Следующие команды **заменяют сгенерированные схему, проект и PCB**, включая ручные правки этих файлов. Используйте копию каталога, если уже редактировали проект. Они восстанавливают итоговую разводку из сохранённой сессии, без повторного запуска автотрассировщика.

```bash
/usr/bin/python3 examples/amp-deformation/scripts/design.py
/usr/bin/python3 examples/amp-deformation/scripts/make_schematic.py
/usr/bin/python3 examples/amp-deformation/scripts/make_pcb.py
/usr/bin/python3 examples/amp-deformation/scripts/import_route.py
/usr/bin/python3 examples/amp-deformation/scripts/finish_pcb.py
kicad-cli sch export netlist --format kicadxml -o examples/amp-deformation/hardware/amp_sensor.net examples/amp-deformation/hardware/amp_sensor.kicad_sch
kicad-cli sch export pdf -o examples/amp-deformation/hardware/amp_sensor.pdf examples/amp-deformation/hardware/amp_sensor.kicad_sch
/usr/bin/python3 examples/amp-deformation/scripts/export_geometry.py
/usr/bin/python3 examples/amp-deformation/scripts/validate_pcb.py
```

`import_route.py` и `finish_pcb.py` применяются ровно один раз после новой платы: повторный запуск добавит дубликаты дорожек. Сессия `amp_sensor_final3.ses` получена Freerouting 1.9.0, после неё добавлены три GND-перехода. Другие `.ses` и routing-логи — история промежуточных проходов. После изменения размещения/цепей старую SES применять нельзя; экспортируйте новый DSN и выполните трассировку заново.

Для регенерации только антенн есть `make_pcb.py --antenna-only`; плата электроники при этом не заменяется. `initial/refined/fine/compact/uhf_*` в results — поисковые варианты. Основные утверждения отчёта относятся только к `compact_final`, `compact_mesh_check`, `compact_body`, а 868-МГц бюджет — к `rectifier_868`, не к FEM коммерческой керамической антенны.
