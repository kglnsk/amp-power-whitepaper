"""Make a distinct, populated 868 MHz electronics project; unchanged net topology/routing."""
from pathlib import Path
import shutil,subprocess,json,pcbnew as k
P=Path(__file__).resolve().parents[1];H=P/'hardware';V=H/'868';V.mkdir(exist_ok=True)
for d in H.glob('*.pretty'):shutil.copytree(d,V/d.name,dirs_exist_ok=True)
for name in ['fp-lib-table','amp_sensor.kicad_pro','amp_sensor.kicad_sch','amp_sensor.kicad_pcb','bom.csv','design.json']:
 text=(H/name).read_text().replace('10n tune / 2450MHz','68n tune / 868MHz').replace('2.45 GHz nominal 10n; 915 MHz variant 68n; tune on assembled PCB','868 MHz nominal 68n; tune on assembled PCB')
 (V/name).write_text(text)
for fmt,ext in [('pdf','pdf'),('netlist','net')]:
 cmd=['kicad-cli','sch','export',fmt]
 if fmt=='netlist':cmd+=['--format','kicadxml']
 subprocess.run(cmd+['-o',str(V/('amp_sensor.'+ext)),str(V/'amp_sensor.kicad_sch')],check=True)
b=k.LoadBoard(str(V/'amp_sensor.kicad_pcb'));b.GetAllNetClasses()['Default'].SetClearance(k.FromMM(.15));k.WriteDRCReport(b,str(P/'results/sensor_868_drc.txt'),k.EDA_UNITS_MILLIMETRES,True)
assert next(f.GetValue() for f in b.GetFootprints() if f.GetReference()=='L1')=='68n tune / 868MHz'
print((P/'results/sensor_868_drc.txt').read_text())

# Compare every assigned schematic net to actual PCB pads in this variant.
import xml.etree.ElementTree as ET
sch={}
for ne in ET.parse(V/'amp_sensor.net').getroot().findall('./nets/net'):
 for node in ne.findall('node'):sch[(node.attrib['ref'],node.attrib['pin'])]=ne.attrib['name'].lstrip('/')
errors=[];count=0
parts=json.loads((V/'design.json').read_text());fps={f.GetReference():f for f in b.GetFootprints()}
for part in parts:
 for pin,net in part['nets'].items():
  if net is None:continue
  count+=1;actual=[pd.GetNetname() for pd in fps[part['ref']].Pads() if pd.GetNumber()==pin]
  if not actual or any(n!=net for n in actual) or sch.get((part['ref'],pin))!=net:errors.append([part['ref'],pin,net,actual])
(P/'results/connectivity_868_check.json').write_text(json.dumps(dict(components=len(parts),checked_pins=count,mismatches=errors,L1='68n tune / 868MHz'),indent=2));assert not errors,errors
