"""Generate native, self-contained KiCad 7 schematic and BOM from design.py."""
from design import *
import uuid,csv
H=ROOT/'hardware';H.mkdir(exist_ok=True)
def uid(s):return str(uuid.uuid5(uuid.NAMESPACE_URL,'amp-deformation/'+s))
def q(s):return json.dumps(str(s),ensure_ascii=False)
def fx(size=1):return f'(effects (font (size {size} {size})))'
root=uid('schematic');symdefs=[];instances=[];wires=[];labels=[];nc=[]
positions={}; cols={'RF':65,'POWER':190,'SENSE':335,'BLE':475}
for group,x in cols.items():
 ps=[p for p in PARTS if p['group']==group];ics=[p for p in ps if p['ref'].startswith('U')];small=[p for p in ps if p not in ics]
 for i,p in enumerate(ics):positions[p['ref']]=(x+(i%2)*62,80 if group=='BLE' else 65)
 start=175 if group=='BLE' else 125 if group=='POWER' else 105 if group=='SENSE' else 50
 for i,p in enumerate(small):positions[p['ref']]=(x-27+(i%2)*64,start+(i//2)*(16 if group=='POWER' else 24))
for p in PARTS:
 ref=p['ref']; pins=sorted(p['pins'].items(),key=lambda kv:int(kv[0])); n=len(pins);half=(n+1)//2; w=12.7 if n>2 else 6.35;h=max(3.81,(half+1)*1.27); coords={};pintext=[]
 for i,(num,(name,typ)) in enumerate(pins):
  left=i<half; row=i if left else i-half; yy=h-2.54-row*2.54;xx=-w-2.54 if left else w+2.54;coords[num]=(xx,yy,left)
  pintext.append(f'(pin {typ} line (at {xx} {yy} {0 if left else 180}) (length 2.54) (name {q(name)} {fx(.9)}) (number {q(num)} {fx(.9)}))')
 graphics=f'(rectangle (start {-w} {h}) (end {w} {-h}) (stroke (width .254) (type default)) (fill (type background)))'
 pinopts='(pin_names (offset .5))'
 if n==2 and ref[0] in 'RC':
  cy=h-2.54
  def line(x1,y1,x2,y2):return f'(polyline (pts (xy {x1} {y1}) (xy {x2} {y2})) (stroke (width .254) (type default)) (fill (type none)))'
  pinopts='(pin_names hide) (pin_numbers hide)'
  if ref[0]=='C':
   graphics=line(-w,cy,-.7,cy)+line(.7,cy,w,cy)+line(-.7,cy-2,-.7,cy+2)+line(.7,cy-2,.7,cy+2)
  else:
   graphics=line(-w,cy,-2.54,cy)+line(2.54,cy,w,cy)+f'(rectangle (start -2.54 {cy+1.016}) (end 2.54 {cy-1.016}) (stroke (width .254) (type default)) (fill (type none)))'
 symdefs.append(f'(symbol "AMP:{ref}" {pinopts} (in_bom yes) (on_board yes) (property "Reference" {q(ref[0])} (at 0 {h+3} 0) {fx()}) (property "Value" {q(p["value"])} (at 0 {h+5} 0) {fx()}) (symbol "{ref}_0_1" {graphics}) (symbol "{ref}_1_1" {" ".join(pintext)}))')
 x,y=positions[ref];su=uid(ref)
 props=' '.join(f'(property {q(k)} {q(v)} (at {x} {y-h-3-j*2} 0) (effects (font (size 1 1)) {"hide" if j>1 else ""}))' for j,(k,v) in enumerate([('Reference',ref),('Value',p['value']),('Footprint',p['footprint']),('Datasheet',p['note'])]))
 instances.append(f'(symbol (lib_id "AMP:{ref}") (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (uuid {su}) {props} '+ ' '.join(f'(pin {q(k)} (uuid {uid(ref+"pin"+k)}))' for k in p['pins'])+f' (instances (project "amp_sensor" (path "/{root}" (reference "{ref}") (unit 1)))))')
 for num,(xx,yy,left) in coords.items():
  px=x+xx;py=y-yy;net=p['nets'].get(num)
  if net is None:nc.append(f'(no_connect (at {px} {py}) (uuid {uid(ref+num+"nc")}))');continue
  lx=px+(-4 if left else 4)
  wires.append(f'(wire (pts (xy {px} {py}) (xy {lx} {py})) (stroke (width 0) (type default)) (uuid {uid(ref+num+"wire")}))')
  labels.append(f'(label {q(net)} (at {lx} {py} 0) (effects (font (size .85 .85)) (justify {"right" if left else "left"} bottom)) (uuid {uid(ref+num+"label")}))')
texts=[]
for g,x in cols.items():texts.append(f'(text {q(g+" / REV A ENGINEERING PROTOTYPE")} (at {x} 20 0) {fx(1.4)} (uuid {uid(g)}))')
texts.append(f'(text "RF matching values provisional. See README and design.json. BLE data link; AMP-powered architecture, no 802.11bp conformance claim." (at 285 385 0) {fx(1.4)} (uuid {uid("warning")}))')
s=f'(kicad_sch (version 20230121) (generator eeschema) (uuid {root}) (paper "A2") (lib_symbols '+''.join(symdefs)+') '+''.join(wires+labels+nc+texts+instances)+')\n'
(H/'amp_sensor.kicad_sch').write_text(s)
(H/'amp_sensor.kicad_pro').write_text(json.dumps({'net_settings':{'classes':[{'name':'Default','clearance':0.15,'track_width':0.2,'via_diameter':0.6,'via_drill':0.3}]}},indent=2))
with (H/'bom.csv').open('w') as f:
 wr=csv.writer(f);wr.writerow(['Reference','Value / MPN','Footprint','Notes']);wr.writerows((p['ref'],p['value'],p['footprint'],p['note']) for p in PARTS)
print('Wrote schematic, project, BOM')
