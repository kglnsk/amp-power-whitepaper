"""Summarize the final, same-geometry FEM runs without re-solving them."""
from pathlib import Path
import json,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]/'results'
names=['compact_final','compact_mesh_check','compact_body'];data={};fig,ax=plt.subplots(1,2,figsize=(11,4))
for name,label in zip(names,['Free space, mesh 0.14','Free space, mesh 0.17','10 mm body spacing, mesh 0.17']):
 d=json.loads((R/(name+'.json')).read_text());f=np.array(d['frequency_hz']);s=np.array(d['s11_db']);ff=np.load(R/(name+'_pattern.npz'));data[name]=dict(s11_2450_db=float(s[np.argmin(abs(f-2.45e9))]),sampled_minimum_hz=float(f[s.argmin()]),peak_gain_in_cut_dBi=float(20*np.log10(ff['gain'].max())))
 ax[0].plot(f/1e9,s,label=label);ax[1].plot(np.rad2deg(ff['angle']),20*np.log10(np.maximum(ff['gain'],1e-6)),label=label)
a=json.loads((R/'compact_final.json').read_text());b=json.loads((R/'compact_mesh_check.json').read_text());data['max_mesh_s11_difference_db']=float(np.max(np.abs(np.array(a['s11_db'])-b['s11_db'])));data['limitations']='Same geometry, two mesh settings only; no ABC-domain convergence; gain is peak in one cut, not full sphere.'
(R/'antenna_checks.json').write_text(json.dumps(data,indent=2))
ax[0].axhline(-10,c='gray',ls='--');ax[0].set(xlabel='Frequency (GHz)',ylabel='S11 (dB)');ax[1].set(xlabel='Cut angle (deg)',ylabel='Gain (dBi)',ylim=(-30,6))
for aa in ax:aa.grid();aa.legend(fontsize=7)
fig.tight_layout();fig.savefig(R/'antenna_comparison.png',dpi=180);print(json.dumps(data,indent=2))
