"""Native PCB generation using distribution KiCad pcbnew Python API."""
from design import *
import pcbnew as k,uuid,math,shutil
H=ROOT/'hardware';(H/'AMP.pretty').mkdir(exist_ok=True)
def layerset(*ls):
 s=k.LSET()
 for l in ls:s.AddLayer(l)
 return s
def v(x,y):return k.VECTOR2I(k.FromMM(float(x)),k.FromMM(float(y)))
def net(b,name):
 n=k.NETINFO_ITEM(b,name);b.Add(n);return n

def outline(b,w,h):
 for p,q in [((0,0),(w,0)),((w,0),(w,h)),((w,h),(0,h)),((0,h),(0,0))]:
  s=k.PCB_SHAPE();s.SetShape(k.SHAPE_T_SEGMENT);s.SetStart(v(*p));s.SetEnd(v(*q));s.SetLayer(k.Edge_Cuts);s.SetWidth(k.FromMM(.05));b.Add(s)
def text(b,s,x,y,size=1):
 t=k.PCB_TEXT(b);t.SetText(s);t.SetPosition(v(x,y));t.SetTextSize(v(size,size));t.SetTextThickness(k.FromMM(.12));t.SetLayer(k.F_SilkS);b.Add(t)
def zone(b,n,layer,pts):
 z=k.ZONE(b);z.SetLayer(layer);z.SetNet(n);z.SetLocalClearance(k.FromMM(.2));z.SetPadConnection(k.ZONE_CONNECTION_FULL);poly=z.Outline();poly.NewOutline()
 for p in pts:poly.Append(*[k.FromMM(float(t)) for t in p])
 b.Add(z);return z

def pad(fp,num,x,y,sx,sy,n=None,layers=None):
 p=k.PAD(fp);p.SetNumber(str(num));p.SetAttribute(k.PAD_ATTRIB_SMD);p.SetShape(k.PAD_SHAPE_RECT);p.SetSize(v(sx,sy));p.SetPosition(v(x,y));p.SetPos0(v(x,y));p.SetLayerSet(layers or layerset(k.F_Cu,k.F_Paste,k.F_Mask));
 if n:p.SetNet(n)
 fp.Add(p);return p
# SC79 based on package outline; conservative solder lands, assembly band marks ANODE.
f=k.FOOTPRINT(None);f.SetValue('SMS7630-079LF');f.SetReference('D');f.Reference().SetPos0(v(0,-1.4));f.SetFPID(k.LIB_ID('AMP','SC79'));pad(f,1,-.9,0,.7,.8);pad(f,2,.9,0,.7,.8)
s=k.FP_SHAPE(f);s.SetShape(k.SHAPE_T_RECT);s.SetStart0(v(-.6,-.45));s.SetEnd0(v(.6,.45));s.SetLayer(k.F_Fab);s.SetWidth(k.FromMM(.1));f.Add(s)
k.FootprintSave(str(H/'AMP.pretty'),f)
(H/'fp-lib-table').write_text('(fp_lib_table (lib (name "AMP")(type "KiCad")(uri "${KIPRJMOD}/AMP.pretty")(options "")(descr "Project-specific footprints")))')
import sys
if '--antenna-only' not in sys.argv:
 b=k.BOARD();b.GetDesignSettings().SetBoardThickness(k.FromMM(1.6));outline(b,75,38)
 names=sorted({n for p in PARTS for n in p['nets'].values() if n});nets={n:net(b,n) for n in names};fps={}
 for p in PARTS:
  lib,fn=p['footprint'].split(':');base=str(H/'AMP.pretty') if lib=='AMP' else '/usr/share/kicad/footprints/'+lib+'.pretty'
  f=k.FootprintLoad(base,fn)
  if f is None:raise RuntimeError(p['footprint'])
  f.SetReference(p['ref']);f.SetValue(p['value']);f.SetFPID(k.LIB_ID(lib,fn));f.SetPath(k.KIID_PATH('/'+str(uuid.uuid5(uuid.NAMESPACE_URL,'amp-deformation/schematic'))+'/'+str(uuid.uuid5(uuid.NAMESPACE_URL,'amp-deformation/'+p['ref']))))
  b.Add(f);f.SetPosition(v(*p['xy']));fps[p['ref']]=f
  if p['ref'] in ['C'+str(i) for i in range(10,18)]:f.SetOrientationDegrees(90)
  f.Reference().SetTextSize(v(.8,.8));f.Reference().SetTextThickness(k.FromMM(.1));f.Value().SetVisible(False)
  for pd in f.Pads():
   n=p['nets'].get(pd.GetNumber());
   if n:pd.SetNet(nets[n])
   elif pd.GetNumber():pd.SetNet(net(b,'unconnected-('+p['ref']+'-'+pd.GetNumber()+')'))
 # Bottom copper excludes module antenna end (module y=2.15..5.1); also keep top copper empty here.
 zone(b,nets['GND'],k.B_Cu,[(.3,.3),(52,.3),(52,6),(74.7,6),(74.7,37.7),(.3,37.7)])
 text(b,'AMP / BLE  REV A',16,2,1.1);text(b,'3.0V PRECHARGE',10,19,.8);text(b,'BODY MOTION',49,35,.8)
 b.GetAllNetClasses()['Default'].SetClearance(k.FromMM(.15))
 k.SaveBoard(str(H/'amp_sensor.kicad_pcb'),b)
# Standalone antenna coupon: same polygon as the EMerge script, no solder mask on radiator.
def antenna(name,BW,BH,W,L,inset,y0,h=1.6):
 b=k.BOARD();b.GetDesignSettings().SetBoardThickness(k.FromMM(h));outline(b,BW,BH);rf=net(b,'ANT');g=net(b,'GND');cx=BW/2;w=3.05*h/1.6;gap=1.;x0=cx-W/2;x1=cx+W/2;yb=y0+L;ye=BH-5
 pts=[(x0,y0),(x1,y0),(x1,yb),(cx+w/2+gap,yb),(cx+w/2+gap,yb-inset),(cx+w/2,yb-inset),(cx+w/2,ye),(cx-w/2,ye),(cx-w/2,yb-inset),(cx-w/2-gap,yb-inset),(cx-w/2-gap,yb),(x0,yb)]
 zone(b,rf,k.F_Cu,pts);zone(b,g,k.B_Cu,[(.25,.25),(BW-.25,.25),(BW-.25,BH-.25),(.25,BH-.25)])
 mask=k.PCB_SHAPE(b);mask.SetShape(k.SHAPE_T_POLY);mp=k.SHAPE_POLY_SET();mp.NewOutline()
 for xx,yy in pts:mp.Append(k.FromMM(xx),k.FromMM(yy))
 mask.SetPolyShape(mp);mask.SetFilled(True);mask.SetWidth(0);mask.SetLayer(k.F_Mask);b.Add(mask)
 f=k.FOOTPRINT(b);b.Add(f);f.SetReference('J1');f.SetValue('SOLDER COAX');pad(f,1,cx,ye-1,w,2,rf,layerset(k.F_Cu,k.F_Mask))
 for x in [cx-5,cx+5]:
  pad(f,2,x,ye-1,3,3,g,layerset(k.F_Cu,k.F_Mask))
  vi=k.PCB_VIA(b);vi.SetPosition(v(x,ye-1));vi.SetWidth(k.FromMM(.7));vi.SetDrill(k.FromMM(.35));vi.SetViaType(k.VIATYPE_THROUGH);vi.SetLayerPair(k.F_Cu,k.B_Cu);vi.SetNet(g);b.Add(vi)
 f.Reference().SetVisible(False);f.Value().SetVisible(False)
 f.SetFPID(k.LIB_ID('AMP','Coax_'+name));k.FootprintSave(str(H/'AMP.pretty'),f)
 text(b,name+f' / FR4 {h}',cx,4,1)
 k.SaveBoard(str(H/(name+'.kicad_pcb')),b)
 b=k.LoadBoard(str(H/(name+'.kicad_pcb')));b.BuildConnectivity();filler=k.ZONE_FILLER(b);filler.Fill(b.Zones());k.SaveBoard(str(H/(name+'.kicad_pcb')),b)
 (H/(name+'.json')).write_text(json.dumps(dict(width=BW,height=BH,patch_polygon=pts,ground='bottom plane with 0.25 mm edge setback',thickness=h,er=4.3,tand=.02),indent=2))
antenna('antenna_2450',49,49,37.6,28.6,9,5.5)
antenna('antenna_915_hypothesis',100,110,80,78.4,25,10)
antenna('antenna_868_fr4',120,120,100,81.7,27,8,3.2)
# Bundle only used vendor footprints for a portable project.
entries=[]
for lib in sorted({p['footprint'].split(':')[0] for p in PARTS}):
 target=H/(lib+'.pretty');target.mkdir(exist_ok=True)
 if lib!='AMP':
  for part in PARTS:
   ll,fn=part['footprint'].split(':')
   if ll==lib:shutil.copyfile('/usr/share/kicad/footprints/'+lib+'.pretty/'+fn+'.kicad_mod',target/(fn+'.kicad_mod'))
 entries.append('(lib (name '+json.dumps(lib)+')(type "KiCad")(uri "${KIPRJMOD}/'+lib+'.pretty")(options "")(descr "Bundled used footprints"))')
(H/'fp-lib-table').write_text('(fp_lib_table '+''.join(entries)+')')
print('Saved sensor placement and two antenna coupons')
