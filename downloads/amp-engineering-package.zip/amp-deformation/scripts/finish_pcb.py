"""Finish RF-module ground stitching after autorouting and run physical DRC."""
from pathlib import Path
import pcbnew as k
P=Path(__file__).resolve().parents[1];path=P/'hardware/amp_sensor.kicad_pcb';b=k.LoadBoard(str(path));g=b.FindNet('GND')
def v(x,y):return k.VECTOR2I(k.FromMM(x),k.FromMM(y))
def seg(a,c):
 t=k.PCB_TRACK(b);t.SetStart(v(*a));t.SetEnd(v(*c));t.SetWidth(k.FromMM(.2));t.SetLayer(k.F_Cu);t.SetNet(g);b.Add(t)
def via(x,y):
 t=k.PCB_VIA(b);t.SetPosition(v(x,y));t.SetWidth(k.FromMM(.6));t.SetDrill(k.FromMM(.3));t.SetViaType(k.VIATYPE_THROUGH);t.SetLayerPair(k.F_Cu,k.B_Cu);t.SetNet(g);b.Add(t)
for a,c in [((58.35,6.25),(57.4,6.65)),((67.65,6.25),(68.6,6.65)),((67.8,17.9146),(70.,18.4))]:seg(a,c);via(*c)
b.GetAllNetClasses()['Default'].SetClearance(k.FromMM(.15));b.BuildConnectivity();filler=k.ZONE_FILLER(b);filler.Fill(b.Zones());k.SaveBoard(str(path),b)
k.WriteDRCReport(b,str(P/'results/sensor_drc.txt'),k.EDA_UNITS_MILLIMETRES,True)
print((P/'results/sensor_drc.txt').read_text())
