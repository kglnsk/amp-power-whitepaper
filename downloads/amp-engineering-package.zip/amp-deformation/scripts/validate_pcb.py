"""Read existing CAD and report DRC. Does not change copper or placement."""
from pathlib import Path
import pcbnew as k
P=Path(__file__).resolve().parents[1]
for name in ['amp_sensor','antenna_2450','antenna_915_hypothesis','antenna_868_fr4']:
 b=k.LoadBoard(str(P/'hardware'/(name+'.kicad_pcb')))
 if name=='amp_sensor':b.GetAllNetClasses()['Default'].SetClearance(k.FromMM(.15))
 file=P/'results'/('sensor_drc.txt' if name=='amp_sensor' else name+'_drc.txt')
 k.WriteDRCReport(b,str(file),k.EDA_UNITS_MILLIMETRES,True)
 s=file.read_text();print(s)
 assert '** Found 0 DRC violations **' in s and '** Found 0 unconnected pads **' in s
