"""Publishable repository: report, media, data and downloadable attachments only.
The executable research sources live inside the downloadable engineering archive.
"""
from pathlib import Path
import json,shutil,re,argparse,hashlib
from urllib.parse import unquote,quote
P=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args();source=P/'report/dist';out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
for name in ['index.html','style.css','app.js','favicon.svg','whitepaper.pdf','.nojekyll']:
 if (source/name).exists():shutil.copyfile(source/name,out/name)
for name in ['assets','downloads','vendor']:shutil.copytree(source/name,out/name,dirs_exist_ok=True)
raw=(source/'report-data.js').read_text();data=json.loads(raw.removeprefix('window.REPORT_DATA=').rstrip(';\n'));mapping={};published=[]
for row in data['files']:
 rel=Path(row['path']);suffix=rel.suffix.lower()
 if suffix in ['.png','.svg','.jpeg','.jpg','.webp','.glb']:dest=Path('media')/rel
 elif suffix in ['.json','.csv','.npz','.s1p','.pdf','.kicad_pcb','.kicad_sch','.kicad_pro']:dest=Path('downloads')/rel
 elif suffix=='.txt' and ('drc' in rel.name or 'check' in rel.name):dest=Path('downloads')/rel
 else:continue
 to=out/dest;to.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/'files'/rel,to);url=quote(str(dest));mapping['files/'+str(rel)]=url;published.append(row|{'url':url})
html=(out/'index.html').read_text()
def sub(m):
 url=unquote(m.group(2))
 if url=='files/COTS_868.md':new='#alternatives'
 elif url=='files/scripts/REPRODUCE.md':new='downloads/amp-engineering-package.zip'
 else:new=mapping[url]
 return m.group(1)+new+m.group(3)
html=re.sub(r'((?:href|src|poster)=\")(files/[^\"]+)(\")',sub,html)
html=html.replace('<option value="scripts">Скрипты</option>','')
html=html.replace('Как воспроизвести</a>','Скрипты и инструкции (ZIP)</a>')
html=html.replace('Найти файл: .s1p, BOM, render, SPICE…','Найти файл: .s1p, BOM, render…')
html=html.replace('<p id="file-count"', '<p class="small">В каталоге — иллюстрации, данные и вложения, которые можно открыть отдельно. Полные скрипты и журналы лежат в ZIP-пакете.</p><p id="file-count"')
(out/'index.html').write_text(html)
data['files']=published;(out/'report-data.js').write_text('window.REPORT_DATA='+json.dumps(data,ensure_ascii=False)+';\n')
js=(out/'app.js').read_text().replace("a.href='files/'+f.path.split('/').map(encodeURIComponent).join('/');", "a.href=f.url;");(out/'app.js').write_text(js)
(out/'manifest.json').write_text(json.dumps(published,indent=2,ensure_ascii=False))
print(json.dumps(dict(path=str(out),files=len(published),report_only=True),indent=2))
