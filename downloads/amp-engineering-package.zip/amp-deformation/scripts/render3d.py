"""Software-rendered 3D CAD visualization; bodies are simplified, copper is from KiCad."""
from pathlib import Path
import json,numpy as np,pyvista as pv,argparse
ap=argparse.ArgumentParser();ap.add_argument("--band",choices=["2450","868"],default="2450");args=ap.parse_args();large=args.band=="868"
P=Path(__file__).resolve().parents[1];g=json.loads((P/'results/board_geometry.json').read_text());a=json.loads((P/('hardware/antenna_868_fr4.json' if large else 'hardware/antenna_2450.json')).read_text())
p=pv.Plotter(off_screen=True,window_size=(1600,1500));p.set_background('#101c2b');ox,oy=(-22.5,55) if large else (13,45);aw=a['width'];ah=a['height'];az=a['thickness']

def box(center,size,color):p.add_mesh(pv.Cube(center=center,x_length=size[0],y_length=size[1],z_length=size[2]),color=color,smooth_shading=False,ambient=.3,diffuse=.7,specular=.25)
def polygon(xy,z,color):
 pts=np.c_[xy,np.full(len(xy),z)];mesh=pv.PolyData(pts,[len(pts),*range(len(pts))]);p.add_mesh(mesh.triangulate(),color=color,ambient=.35,specular=.6)
box((37.5,19,.8),(75,38,1.6),'#15664b');box((ox+aw/2,oy+ah/2,az/2),(aw,ah,az),'#15664b');polygon((np.array([aw,ah])-np.array(a['patch_polygon']) if large else np.array(a['patch_polygon']))+[ox,oy],az+.04,'#d4b978')
for t in g['tracks']:
 if t['layer']=='top':
  pa=np.r_[t['start'],1.65];pb=np.r_[t['end'],1.65]
  if np.linalg.norm(pa-pb)>.001:p.add_mesh(pv.Line(pa,pb).tube(radius=t['width']/2,n_sides=6),color='#b6a66c')
for pd in g['pads']:
 x,y=pd['xy'];w,h=pd['size'];ang=np.deg2rad(pd['rotation']);r=np.array([[np.cos(ang),-np.sin(ang)],[np.sin(ang),np.cos(ang)]]);corn=np.array([[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]])@r.T+[x,y];polygon(corn,1.71,'#c5ced0')
for c in g['parts']:
 ref=c['ref'];x,y=c['xy'];fp=c['footprint'];color='#303740';w,h,z=1.6,.8,.7
 if ref=='U4':w,h,z=10.5,15.5,2.2;color='#c1cbd0'
 elif ref=='U3':w,h,z=3.25,3.,1.06
 elif ref=='U1':w,h,z=3,3,.9
 elif ref=='U2':w,h,z=2.9,2.8,1.1
 elif ref=='L2':w,h,z=4,4,1.8
 elif ref.startswith('TP'):continue
 elif ref.startswith('C'):
  color='#c7ad86'
  if '1210' in fp:w,h,z=2.5,3.2,2.5
 elif ref.startswith('D'):w,h,z=1.2,.8,.6
 elif ref.startswith('J'):
  if ref=='J1':w,h,z=3,3,1.25;color='#c6b36a'
  else:
   count=5 if ref=='J2' else 2
   for i in range(count):box((x,y+i*2.54,2.5),(2,2,1.7),'#29313a');box((x,y+i*2.54,4),(.6,.6,3),'#bba76b')
   continue
 box((x,y,1.72+z/2),(w,h,z),color)
 if ref=='U4':box((x,y-5.7,4),(7.5,3,1),'#2673a2')
for v in g['vias']:
 x,y=v['xy'];p.add_mesh(pv.Disc(center=(x,y,1.73),inner=v['drill']/2,outer=v['diameter']/2,normal=(0,0,1),c_res=12),color='#c3ba8b')
# Coax is shown as an assembly interconnect, not a simulated RF cable.
path=np.array([[6,8,3],[4,20,5],[5,37,6],[8,49,6],[ox+aw/2,oy+(6 if large else ah-6),az+1.4]])
p.add_mesh(pv.Spline(path,100).tube(radius=.6),color='#141922')
p.add_text(('868 MHz / FR4 rectenna + BLE' if large else 'AMP rectenna + BLE motion sensor'),position='upper_left',font_size=22,color='white');p.add_text(('120 x 120 x 3.2 mm FR4 antenna | 75 x 38 mm electronics\nCAD-derived geometry; simplified component bodies' if large else '49 x 49 mm antenna | 75 x 38 mm electronics\nCAD copper and placement; simplified component bodies'),position='lower_left',font_size=13,color='#bdd0db')
p.camera_position=[(135,-105,190),(37,47,0),(0,0,1)];p.camera.parallel_projection=True;p.camera.parallel_scale=66
if large:p.camera_position=[(175,-145,280),(37,85,0),(0,0,1)];p.camera.parallel_projection=True;p.camera.parallel_scale=107
p.enable_anti_aliasing('ssaa');p.show(screenshot=str(P/('results/assembly_868_3d.png' if large else 'results/assembly_3d.png')))
