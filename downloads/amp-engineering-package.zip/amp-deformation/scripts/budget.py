"""Reproducible link, nonlinear harvesting, storage and workload estimates.
All powers in SI internally; deployment scenarios are assumptions, not demo measurements.
"""
from pathlib import Path
import json,csv,math
import numpy as np
P=Path(__file__).resolve().parents[1];R=P/'results';c=299792458.
# Load powers at average rail 3 V. These are design allocations, not measured firmware.
loads={'sensor_normal_uW':9.,'mcu_sleep_retained_uW':9.,'fifo_and_processing_uW':12.,'switch_uW':1.5,'margin_uW':8.5}
active=sum(loads.values())*1e-6
idle=2.5e-6 # BQ25504 + divider sampling + MLCC + PCB leakage design allowance
Efeatures=active*20+120e-6 # 20 s acquisition, feature packet + boot allowance
Eraw=active*20+5.2e-3 # conservative BLE connection/raw 12kB transfer incl CPU and retries
Cnom=8*220e-6;Ceff=Cnom*.5;Von=1.25*(1+(4.12+1.65)/4.12);Voff=2.5;Vov=1.875*(1+4.22/5.62)
Ecap=.5*Ceff*(Von**2-Voff**2)
def curve(folder):
 rows=json.loads((R/folder/'sweep.json').read_text());db=np.array(sorted({x['dbm'] for x in rows}))
 p=np.array([max(0,max(x['pdc_W'] for x in rows if x['dbm']==d)) for d in db]);cs=np.array([max(0,next(x['pdc_W'] for x in rows if x['dbm']==d and x['V']==.7)) for d in db])
 return db,p,cs
curves={2450:curve('rectifier'),915:curve('rectifier_915')}
def evaluate(name,band,eirp,d,duty,gain,loss):
 fspl=20*math.log10(4*math.pi*d*band*1e6/c);pr=eirp+gain-loss-fspl;grid,p,cs=curves[band]
 # Above -5dBm clamp to last characterized value: conservative bound, do not extrapolate.
 pdc=float(np.interp(pr,grid,p,left=0));cold=float(np.interp(pr,grid,cs,left=0));harvest=pdc*duty*.70*.70 # boost conversion x implementation derating
 net=harvest-idle
 return dict(scenario=name,band_MHz=band,eirp_dBm=eirp,distance_m=d,rf_duty=duty,receive_gain_dBi=gain,other_losses_dB=loss,rf_on_dBm=pr,pdc_on_model_uW=pdc*1e6,storage_average_uW=harvest*1e6,net_idle_uW=net*1e6,cold_start_power_only=(cold*duty>=15e-6),feature_cycle_s=(max(20,Efeatures/net) if net>0 else None),raw_cycle_s=(max(20,Eraw/net) if net>0 else None),raw_paced_cycle_s=(max(20,Eraw/(net-9e-6)) if net>9e-6 else None),clamped_above_simulation=bool(pr>grid[-1]))
rows=[]
for name,band,eirp,duty,gain,loss in [('WiFi idle',2450,20,.02,3,6),('WiFi busy',2450,20,.5,3,6),('WPT 2.45GHz 1W EIRP',2450,30,.9,3,6),('WPT 2.45GHz 4W EIRP',2450,36,.9,3,6),('WPT 915MHz FR4',915,30,.9,-1,6)]:
 for d in [.5,1,3,5]:rows.append(evaluate(name,band,eirp,d,duty,gain,loss))
summary=dict(assumptions='Friis LOS, RF duty applies after nonlinear rectification; no jurisdictional permission implied by EIRP; peak RF waveform assumed sine, OFDM needs measurement',loads=loads,active_uW=active*1e6,idle_uW=idle*1e6,feature_event_mJ=Efeatures*1e3,raw_event_mJ=Eraw*1e3,C_nominal_mF=Cnom*1e3,C_effective_mF=Ceff*1e3,turn_on_V=Von,turn_off_V=Voff,overvoltage_V=Vov,usable_energy_mJ=Ecap*1e3,feature_fits_20pct_reserve=Efeatures<=.8*Ecap,raw_fits=Eraw<=.8*Ecap,raw_required_effective_mF=2*Eraw/(.8*(Von**2-Voff**2))*1e3,photo_capacitors={'assumed_count':8,'package_hypothesis':'0805','candidate_each_uF':[10,22,47,100],'effective_factor_range':[.2,.6]},scenarios=rows)
(R/'budget.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
with (R/'budget.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(12,4.5))
for band,(db,p,cs) in curves.items():ax[0].semilogy(db,np.maximum(p*1e6,.01),'o-',label=f'{band} MHz, best tested DC clamp')
ax[0].axhline(15,color='gray',ls='--',label='15 uW cold-start power (voltage also required)');ax[0].set(xlabel='Available RF power (dBm)',ylabel='Predicted DC power (uW)',ylim=(.01,300));ax[0].legend(fontsize=7);ax[0].grid()
for name in dict.fromkeys(r['scenario'] for r in rows):
 rr=[r for r in rows if r['scenario']==name];ax[1].loglog([r['distance_m'] for r in rr],[max(.01,r['storage_average_uW']) for r in rr],'o-',label=name)
ax[1].axhline(active*1e6+idle*1e6,color='black',ls='--',label='Acquisition + idle allocation');ax[1].set(xlabel='Distance (m)',ylabel='Average stored power (uW)');ax[1].legend(fontsize=6);ax[1].grid();fig.tight_layout();fig.savefig(R/'energy_budget.png',dpi=200)
print(json.dumps({k:v for k,v in summary.items() if k!='scenarios'},indent=2))
