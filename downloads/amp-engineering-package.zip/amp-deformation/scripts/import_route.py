"""Import Freerouting SES wire/via geometry; KiCad 7 API lacks board-argument SES import."""
from pathlib import Path
import re,json,pcbnew as k
P=Path(__file__).resolve().parents[1];H=P/'hardware'
def parse(s):
 tokens=re.findall(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+',s);stack=[];root=None
 for t in tokens:
  if t=='(':
   a=[]
   if stack:stack[-1].append(a)
   stack.append(a)
  elif t==')':root=stack.pop()
  else:stack[-1].append(t[1:-1] if t.startswith('"') else t)
 return root

def children(a,key):return [x for x in a if isinstance(x,list) and x and x[0]==key]
def pos(x,y):return k.VECTOR2I(round(float(x)*100),round(-float(y)*100)) # um/10 -> nm
b=k.LoadBoard(str(H/'amp_sensor.kicad_pcb'));data=parse((H/'amp_sensor_final3.ses').read_text());routes=children(data,'routes')[0]
res=children(routes,'resolution')[0];assert res[1:]==['um','10'],res
nets={n.GetNetname():n for n in b.GetNetsByNetcode().values()};count=0
for n in children(children(routes,'network_out')[0],'net'):
 ni=nets[n[1]]
 for wire in children(n,'wire'):
  path=children(wire,'path')[0];layer=k.F_Cu if path[1]=='F.Cu' else k.B_Cu;w=round(float(path[2])*100);xy=path[3:]
  for i in range(0,len(xy)-2,2):
   t=k.PCB_TRACK(b);t.SetStart(pos(*xy[i:i+2]));t.SetEnd(pos(*xy[i+2:i+4]));t.SetWidth(w);t.SetLayer(layer);t.SetNet(ni);b.Add(t);count+=1
 for via in children(n,'via'):
  t=k.PCB_VIA(b);t.SetPosition(pos(*via[2:4]));t.SetWidth(k.FromMM(.6));t.SetDrill(k.FromMM(.3));t.SetViaType(k.VIATYPE_THROUGH);t.SetLayerPair(k.F_Cu,k.B_Cu);t.SetNet(ni);b.Add(t)
# Update changed engineering values without changing the connectivity/placement used by router.
from design import PARTS
values={p['ref']:p['value'] for p in PARTS}
for f in b.GetFootprints():
 f.SetValue(values[f.GetReference()])
 if f.GetReference() in ['C'+str(i) for i in range(10,18)]:
  pos=f.GetPosition();f.Reference().SetPosition(k.VECTOR2I(pos.x,k.FromMM(35.3)));f.Reference().SetTextAngle(k.EDA_ANGLE(0,k.DEGREES_T))
 if f.GetReference()=='U1':f.Reference().SetPosition(k.VECTOR2I(k.FromMM(33),k.FromMM(16.8)))
 if f.GetReference()=='J3':f.Reference().SetPosition(k.VECTOR2I(k.FromMM(2.5),k.FromMM(22)))
b.GetAllNetClasses()['Default'].SetClearance(k.FromMM(.15))
b.BuildConnectivity();filler=k.ZONE_FILLER(b);filler.Fill(b.Zones());k.SaveBoard(str(H/'amp_sensor.kicad_pcb'),b)
print(count,'track segments')
print('DRC:',k.WriteDRCReport(b,str(P/'results'/'sensor_drc.txt'),k.EDA_UNITS_MILLIMETRES,True))
