"""CAD-derived visualization: actual copper/pad placement, approximate component envelopes."""
from pathlib import Path
import json,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon,Circle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
P=Path(__file__).resolve().parents[1];R=P/'results';g=json.loads((R/'board_geometry.json').read_text());ant=json.loads((P/'hardware/antenna_2450.json').read_text());ox,oy=13,45
bg='#0d1725';green='#146148';gold='#d8b970';silver='#bfc9d1'
def dimensions(p):
 ref=p['ref'];fp=p['footprint']
 if ref=='U4':return (10.5,15.5,2.2)
 if ref=='U3':return (3.25,3.,1.06)
 if ref=='U1':return (3,3,.9)
 if ref=='U2':return (2.9,2.8,1.1)
 if ref=='L2':return (4,4,1.8)
 if ref.startswith('C') and '1210' in fp:return (2.5,3.2,2.5)
 if ref.startswith('J'):return (2.5,2.5,2.5) if ref!='J1' else (3,3,1.25)
 if ref.startswith('TP'):return (0,0,0)
 if ref.startswith('D'):return(1.2,.8,.6)
 return(1.6,.8,.8)
fig,ax=plt.subplots(figsize=(9,12),facecolor=bg);ax.set_facecolor(bg)
ax.add_patch(Rectangle((0,0),75,38,fc=green,ec='#8a998f'));ax.add_patch(Rectangle((ox,oy),49,49,fc=green,ec='#8a998f'))
ax.add_patch(Polygon(np.array(ant['patch_polygon'])+[ox,oy],fc=gold,ec='#f2deab',lw=.7))
for t in g['tracks']:
 x,y=np.array([t['start'],t['end']]).T;ax.plot(x,y,color='#477d91' if t['layer']=='bottom' else '#b9aa71',lw=max(.3,t['width']*2),alpha=.7)
for p in g['pads']:
 x,y=p['xy'];w,h=p['size'];a=p['rotation'];corners=np.array([[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]]);a=np.deg2rad(a);rot=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]]);ax.add_patch(Polygon(corners@rot.T+[x,y],fc=silver,ec='none'))
for p in g['parts']:
 w,h,z=dimensions(p);x,y=p['xy'];color='#c9ad83' if p['ref'][0]=='C' else '#222a31';color=silver if p['ref']=='U4' else color
 if w:ax.add_patch(Rectangle((x-w/2,y-h/2),w,h,fc=color,ec='#151b21',lw=.5))
 ax.text(x,y+h/2+.8,p['ref'],color='white',fontsize=5,ha='center')
for v in g['vias']:ax.add_patch(Circle(v['xy'],v['diameter']/2,fc=gold));ax.add_patch(Circle(v['xy'],v['drill']/2,fc='#102d24'))
ax.plot([ox+24.5,ox+24.5,8,6],[oy+44,oy+52,43,8],color='#17212b',lw=4)
# Cable is an assembly suggestion; antenna orientation is arbitrary for this exploded top view.
ax.text(37.5,105,'AMP • motion sensor + rectenna',color='white',ha='center',fontsize=16,weight='bold')
ax.text(37.5,100,'2.45 GHz · antenna 49 × 49 mm · sensor board 75 × 38 mm',color='#afc7d4',ha='center',fontsize=9)
ax.text(37.5,-5,'Copper and placement from KiCad. Component bodies are simplified.',color='#afc7d4',ha='center',fontsize=8)
ax.set_aspect('equal');ax.set_xlim(-5,80);ax.set_ylim(-8,110);ax.axis('off');fig.tight_layout();fig.savefig(R/'assembly_top.png',dpi=220,facecolor=bg);plt.close(fig)
print('Rendered top assembly; run render3d.py for the 3D view')
