"""Summarize 868 MHz FR4 FEM, publish figures, and evaluate the real simulated antenna gains."""
from pathlib import Path
import json,math,csv
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
P=Path(__file__).resolve().parents[1];R=P/'results'
load=lambda n:json.loads((R/(n+'.json')).read_text())
names=['fr4_868_final','fr4_868_refined','fr4_868_body','fr4_868_boundary'];labels=['Free space / mesh 0.14','Free space / mesh 0.17','Body / 10 mm spacing','Air margin 140 mm'];colors=['#156b55','#ad4e25','#5183a1','#8b6d9e'];ds={n:load(n) for n in names};f=ds[names[0]];fig,ax=plt.subplots(figsize=(8.5,4.5));plt.rcParams['font.family']='DejaVu Sans'
checks={}
for name,label,color in zip(names,labels,colors):
 d=ds[name];ax.plot(np.array(d['frequency_hz'])/1e6,d['s11_db'],color=color,label=label,lw=1.8);checks[name]={k:d[k] for k in ['peak_realized_gain_dBi','radiation_efficiency_estimate','radiated_power_W']};checks[name]['s11_868_db']=d['s11_db'][np.argmin(abs(np.array(d['frequency_hz'])-868e6))]
ax.axhline(-10,color='gray',ls='--',lw=.8);ax.axvspan(863,870,color='#156b55',alpha=.06);ax.set(xlabel='Frequency (MHz)',ylabel='S11 (dB)',ylim=(-50,0));ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout();fig.savefig(R/'antenna_868_comparison.png',dpi=200);plt.close(fig)
a=np.load(R/'fr4_868_final.npz');b=np.load(R/'fr4_868_refined.npz');checks['mesh_max_complex_s11_difference']=float(max(abs(a['s11']-b['s11'])));checks['mesh_gain_difference_dB']=f['peak_realized_gain_dBi']-ds['fr4_868_refined']['peak_realized_gain_dBi'];c=np.load(R/'fr4_868_boundary.npz');checks['boundary_max_complex_s11_difference']=float(max(abs(a['s11'][::2]-c['s11'])));checks['boundary_gain_difference_dB']=f['peak_realized_gain_dBi']-ds['fr4_868_boundary']['peak_realized_gain_dBi'];checks['notes']='PEC; lossy FR4; first-order ABC; ground without PCB edge setback; no launch or nonlinear co-simulation. One-watt incident port normalization; efficiency = boundary radiated power / accepted port power. No physical measurements.'
(R/'fr4_868_checks.json').write_text(json.dumps(checks,indent=2))
fig,ax=plt.subplots(subplot_kw={'projection':'polar'},figsize=(6,5))
for n,label,color in [(names[0],'Free space',colors[0]),(names[2],'Body phantom',colors[2])]:
 pp=np.load(R/(n+'_pattern.npz'));ax.plot(pp['angle'],20*np.log10(np.maximum(pp['gain'],1e-7)),label=label,color=color)
ax.set_ylim(-20,5);ax.set_theta_zero_location('N');ax.set_title('868 MHz | realized gain, dBi',pad=22);ax.legend(loc='lower right',bbox_to_anchor=(1.28,-.12));fig.tight_layout();fig.savefig(R/'antenna_868_pattern.png',dpi=200);plt.close(fig)
g=json.loads((P/'hardware/antenna_868_fr4.json').read_text());fig,ax=plt.subplots(figsize=(8,7));ax.add_patch(Rectangle((0,0),120,120,fc='#e2ede2',ec='#36594c'));ax.add_patch(Polygon(g['patch_polygon'],fc='#c5aa65',ec='#836f35'))
def dim(a,b,label,offset=(0,0)):
 ax.annotate('',xy=a,xytext=b,arrowprops=dict(arrowstyle='<->',color='#344e46',lw=.9));ax.text((a[0]+b[0])/2+offset[0],(a[1]+b[1])/2+offset[1],label,ha='center',va='center',fontsize=10,color='#213e34')
dim((0,-7),(120,-7),'120 mm',(0,-3));dim((-8,0),(-8,120),'120 mm',(-8,0));dim((10,22),(110,22),'100 mm',(0,-4));dim((104,8),(104,89.7),'81.7 mm',(-12,0));dim((70,62.7),(70,89.7),'27 mm',(9,0));ax.text(60,112,'6.1 mm feed',ha='center',fontsize=9);ax.text(60,136,'FR4 3.2 mm | er 4.3 | tan(delta) 0.02\nFull ground plane on reverse side',ha='center',fontsize=10);ax.set_aspect('equal');ax.set_xlim(-25,130);ax.set_ylim(146,-20);ax.axis('off');fig.tight_layout();fig.savefig(R/'antenna_868_dimensions.png',dpi=200);plt.close(fig)
curves={}
fig,ax=plt.subplots(figsize=(8,4.5))
for mhz,folder,color in [(868,'rectifier_868',colors[0]),(915,'rectifier_915',colors[2]),(2450,'rectifier',colors[1])]:
 rows=load(folder+'/sweep');db=sorted({r['dbm'] for r in rows});power=[max(0,max(r['pdc_W'] for r in rows if r['dbm']==d)) for d in db];cold=[max(0,next(r['pdc_W'] for r in rows if r['dbm']==d and r['V']==.7)) for d in db];curves[str(mhz)]=dict(dbm=db,power=power,cold=cold);ax.semilogy(db,np.maximum(np.array(power)*1e6,.01),'o-',color=color,label=f'{mhz} MHz')
ax.set(xlabel='Available RF power (dBm)',ylabel='DC power envelope (uW)',ylim=(.01,400));ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(R/'rectifier_comparison.png',dpi=200);plt.close(fig)
rows=[]
for mode,gain in [('free',f['peak_realized_gain_dBi']),('body',ds['fr4_868_body']['peak_realized_gain_dBi'])]:
 for eirp in [20,30,36]:
  for d in [.5,1,3,5]:
   for duty in [.02,.5,.9]:
    pr=eirp+gain-6-20*math.log10(4*math.pi*d*868e6/299792458);cv=curves['868'];stored=float(np.interp(pr,cv['dbm'],cv['power'],left=0))*.49*duty;net=stored-2.5e-6;cold=float(np.interp(pr,cv['dbm'],cv['cold'],left=0))*duty
    rows.append(dict(mode=mode,gain_dBi=gain,distance_m=d,eirp_dBm=eirp,duty=duty,other_loss_dB=6,rf_on_dBm=pr,stored_uW=stored*1e6,net_uW=net*1e6,feature_cycle_s=max(20,.00092/net) if net>0 else None,raw_paced_cycle_s=max(20,.006/(net-9e-6)) if net>9e-6 else None,cold_power_screen=cold>=15e-6,curve_clamped=pr>cv['dbm'][-1]))
(R/'budget_fr4_868.json').write_text(json.dumps(dict(assumptions=checks['notes']+'; duty after RF conversion; 6 dB added losses; boost 0.7 x implementation 0.7; idle 2.5uW; sample event 0.92mJ. No regulatory permission implied.',scenarios=rows),indent=2))
with (R/'budget_fr4_868.csv').open('w') as out:
 w=csv.DictWriter(out,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(R/'web_curves.json').write_text(json.dumps(curves));print(json.dumps(checks,indent=2))
