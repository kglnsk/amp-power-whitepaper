"""Export actual KiCad pad/track placements for geometry-based visualizations."""
from pathlib import Path
import pcbnew as k,json
from design import PARTS
P=Path(__file__).resolve().parents[1];b=k.LoadBoard(str(P/'hardware/amp_sensor.kicad_pcb'));parts={p['ref']:p for p in PARTS};out={'parts':[],'pads':[],'tracks':[],'vias':[]}
def xy(v):return [k.ToMM(v.x),k.ToMM(v.y)]
for f in b.GetFootprints():
 ref=f.GetReference();p=parts[ref];out['parts'].append(dict(ref=ref,value=p['value'],xy=xy(f.GetPosition()),rotation=f.GetOrientationDegrees(),footprint=p['footprint']))
 for pd in f.Pads():out['pads'].append(dict(ref=ref,number=pd.GetNumber(),xy=xy(pd.GetPosition()),size=xy(pd.GetSize()),rotation=pd.GetOrientationDegrees(),net=pd.GetNetname(),drill=xy(pd.GetDrillSize())))
for t in b.GetTracks():
 if isinstance(t,k.PCB_VIA):out['vias'].append(dict(xy=xy(t.GetPosition()),diameter=k.ToMM(t.GetWidth()),drill=k.ToMM(t.GetDrill())))
 else:out['tracks'].append(dict(start=xy(t.GetStart()),end=xy(t.GetEnd()),width=k.ToMM(t.GetWidth()),layer='top' if t.GetLayer()==k.F_Cu else 'bottom',net=t.GetNetname()))
(P/'results/board_geometry.json').write_text(json.dumps(out,indent=2))
# Reconcile exported KiCad netlist with the actual pads on the board.
import xml.etree.ElementTree as ET
root=ET.parse(P/'hardware/amp_sensor.net').getroot();sch={}
for ne in root.findall('./nets/net'):
 for node in ne.findall('node'):sch[(node.attrib['ref'],node.attrib['pin'])]=ne.attrib['name'].lstrip('/')
errors=[]
for p in PARTS:
 for num,n in p['nets'].items():
  if n is None:continue
  actual=[x['net'] for x in out['pads'] if x['ref']==p['ref'] and x['number']==num]
  if not actual or any(x!=n for x in actual) or sch.get((p['ref'],num))!=n:errors.append([p['ref'],num,n,actual,sch.get((p['ref'],num))])
(P/'results/connectivity_check.json').write_text(json.dumps(dict(components=len(PARTS),checked_pins=sum(n is not None for p in PARTS for n in p['nets'].values()),mismatches=errors),indent=2));assert not errors,errors
print('Connectivity matches schematic and PCB')
