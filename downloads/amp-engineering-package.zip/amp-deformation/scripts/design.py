"""Single source of component connectivity, BOM and draft placement (millimetres)."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
PARTS=[]
def libpins(lib,name):
 s=Path('/usr/share/kicad/symbols',lib+'.kicad_sym').read_text();start=s.index('  (symbol "'+name+'"');end=s.find('\n  (symbol "',start+10);s=s[start:end if end>0 else None]
 return {num:(nam,typ) for typ,nam,num in re.findall(r'\(pin (\w+) \w+ .*?\(name "([^"]+)".*?\(number "([^"]+)"',s,re.S)}
def part(ref,value,fp,pins,nets,xy,group,mpn='',note=''):
 PARTS.append(dict(ref=ref,value=value,footprint=fp,pins=pins,nets={str(k):v for k,v in nets.items()},xy=xy,group=group,mpn=mpn or value,note=note))
def two(ref,val,n1,n2,xy,group='POWER',fp=None,note=''):
 kind=ref[0];fp=fp or {'R':'Resistor_SMD:R_0603_1608Metric','C':'Capacitor_SMD:C_0603_1608Metric','L':'Inductor_SMD:L_0603_1608Metric','D':'Diode_SMD:D_SOD-323'}[kind]
 pins={'1':('A' if kind=='D' else '1','passive'),'2':('K' if kind=='D' else '2','passive')}
 part(ref,val,fp,pins,({1:n2,2:n1} if kind=='D' else {1:n1,2:n2}),xy,group,note=note)
# RF input and two-diode Greinacher voltage doubler. D1 A=GND K=PUMP; D2 A=PUMP K=RECT.
part('J1','RF_IN','Connector_Coaxial:U.FL_Hirose_U.FL-R-SMT-1_Vertical',{'1':('RF','passive'),'2':('GND','passive')},{1:'RF_IN',2:'GND'},(6,8),'RF')
two('C1','DNP tune','RF_IN','GND',(10,10),'RF',note='Shunt matching; tune with nonlinear load, initially unpopulated')
two('L1','10n tune / 2450MHz','RF_IN','RF_MATCH',(13,8),'RF',note='2.45 GHz nominal 10n; 915 MHz variant 68n; tune on assembled PCB')
two('C2','100p C0G','RF_MATCH','PUMP',(17,8),'RF')
two('D1','SMS7630-079LF','PUMP','GND',(20,10),'RF',fp='AMP:SC79',note='SC79; package Ls 0.7 nH; band marks ANODE, not cathode')
two('D2','SMS7630-079LF','RECT','PUMP',(23,8),'RF',fp='AMP:SC79')
two('C3','100p C0G','RECT','GND',(26,10),'RF')
two('C4','4.7u 10V','RECT','GND',(27,14),'RF')
# Datasheet divider convention: lower resistor suffix 1; VRDIV is sampled, not DC VSTOR.
part('U1','BQ25504','Package_DFN_QFN:VQFN-16-1EP_3x3mm_P0.5mm_EP1.68x1.68mm',libpins('Battery_Management','BQ25504'),{1:'GND',2:'RECT',3:'MPPT',4:'VREF',5:'GND',6:'OV',7:'VRDIV',8:'UV',9:'OK_HYST',10:'OK_PROG',11:'POWER_OK',12:'GND',13:'GND',14:'STORE',15:'VSTOR',16:'SW',17:'GND'},(33,14),'POWER')
two('L2','22u Isat>=300mA','RECT','SW',(33,9),fp='Inductor_SMD:L_Taiyo-Yuden_NR-40xx')
two('C5','4.7u 10V','VSTOR','GND',(37,12))
two('C6','10n C0G','VREF','GND',(29,18))
two('R1','10M','RECT','MPPT',(25,18));two('R2','10M','MPPT','GND',(25,21))
two('R3','5.62M 0.1%','OV','GND',(31,24));two('R4','4.22M 0.1%','VRDIV','OV',(31,21))
two('R5','5.62M 0.1%','UV','GND',(35,24));two('R6','4.42M 0.1%','VRDIV','UV',(35,21))
# OFF=2.50 V, ON=3.00 V, OV=3.283 V; worst-case OV tolerance must remain <3.5 V.
two('R7','4.12M 0.1%','OK_PROG','GND',(39,27));two('R8','4.12M 0.1%','OK_HYST','OK_PROG',(39,24));two('R9','1.65M 0.1%','VRDIV','OK_HYST',(39,21))
for i in range(8):two('C'+str(10+i),'220u 6.3V X5R','STORE','GND',(5+4*i,32),fp='Capacitor_SMD:C_1210_3225Metric',note='8 x 220u nominal; design assumes 880u total effective after DC bias; qualify vendor curve')
part('U2','TPS22917DBV','Package_TO_SOT_SMD:SOT-23-6',libpins('Power_Management','TPS22917DBV'),{1:'VSTOR',2:'GND',3:'POWER_OK',4:None,5:'QOD',6:'VDD'},(43,14),'POWER')
two('R10','1k','QOD','VDD',(43,18),note='Output discharge when off; verify ADXL362 off interval >=200ms and rise-time on oscilloscope')
two('C7','10u 6.3V','VDD','GND',(48,17));two('C8','100n','VDD','GND',(48,12))
# Motion sensor plus its on-chip temperature channel; not skin-temperature calibrated.
adnames=['VDDIO','NC','RES','SCLK','RES','MOSI','MISO','CS','INT2','RES','INT1','GND','GND','VS','NC','GND']
adtypes=['power_in','no_connect','passive','input','passive','input','output','input','bidirectional','passive','bidirectional','power_in','passive','power_in','no_connect','passive']
part('U3','ADXL362BCCZ','Sensor_Motion:Analog_LGA-16_3.25x3mm_P0.5mm_LayoutBorder3x5y',{str(i+1):(n,t) for i,(n,t) in enumerate(zip(adnames,adtypes))},{1:'VDD',2:None,3:'GND',4:'SCLK',5:'GND',6:'MOSI',7:'MISO',8:'CS',9:None,10:'GND',11:'INT1',12:'GND',13:'GND',14:'VS_SENSOR',15:None,16:'GND'},(48,27),'SENSE')
two('R11','10R','VDD','VS_SENSOR',(46,23),'SENSE');two('C20','100n','VS_SENSOR','GND',(49,23),'SENSE');two('C21','100n','VDD','GND',(43,27),'SENSE');two('R12','1M','VDD','CS',(45,30),'SENSE')
pins=libpins('RF_Module','MDBT50Q-1MV2');nets={k:None for k in pins}
for k,(n,t) in pins.items():
 if n=='GND':nets[k]='GND'
 if n in ('VDD','VDDH'):nets[k]='VDD'
for pin,net in {20:'SCLK',21:'MOSI',22:'MISO',23:'CS',24:'INT1',40:'RESET',51:'SWDIO',53:'SWDCLK'}.items():nets[str(pin)]=net
part('U4','MDBT50Q-1MV2','RF_Module:Raytac_MDBT50Q',pins,nets,(63,10),'BLE',note='nRF52840; normal-voltage supply VDD=VDDH; DCCH/VBUS/USB NC; internal LFRC initially; module includes RF matching')
two('C22','10u 6.3V','VDD','GND',(57,20),'BLE');two('C23','100n','VDD','GND',(60,20),'BLE')
part('J2','SWD / VTREF','Connector_PinHeader_2.54mm:PinHeader_1x05_P2.54mm_Vertical',{str(i+1):(n,'passive') for i,n in enumerate(['VTREF','SWDIO','SWDCLK','GND','RESET'])},{1:'VDD',2:'SWDIO',3:'SWDCLK',4:'GND',5:'RESET'},(65,24),'BLE',note='VTREF is sense only; disconnect debugger for power measurement')
part('J3','PRECHARGE 3.0V','Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical',{'1':('STORE','passive'),'2':('GND','passive')},{1:'STORE',2:'GND'},(5,22),'POWER',note='Current-limited bench precharge; not USB or 5V')
for i,(net,xy) in enumerate([('RECT',(23,5)),('VSTOR',(38,8)),('POWER_OK',(43,8)),('VDD',(51,18)),('GND',(20,24))]):
 part('TP'+str(i+1),net,'TestPoint:TestPoint_Pad_D1.0mm',{'1':(net,'passive')},{1:net},xy,'POWER')
if __name__=='__main__':
 (ROOT/'hardware'/'design.json').write_text(json.dumps(PARTS,indent=2))
 print(len(PARTS),'components')
