"""Nonlinear ngspice characterization at clamped output voltages.
DC clamp emulates a PMIC operating point; not a cold-start simulation of BQ25504.
RF pads/traces and MLCC ESL are absent. Efficiencies are predictions, not measurements.
"""
from pathlib import Path
import subprocess,math,re,json,itertools,shutil
P=Path(__file__).resolve().parents[1];OUT=P/'results'/'rectifier';OUT.mkdir(exist_ok=True)
NG=shutil.which('ngspice') or str(P/'.tools/ngspice/usr/bin/ngspice')
MODEL='.model SMS D(Is=5u Rs=20 N=1.05 Tt=10p Cjo=.14p M=.4 Eg=.69 Xti=2 Fc=.5 Bv=2 Ibv=100u Vj=.34)'
def run(dbm=-10,L=6.8,C=.01,V=.2,f=2.45e9,stop=1e-6,tag='test'):
 power=10**((dbm-30)/10);amp=math.sqrt(8*50*power)
 deck=f'''SMS7630-079LF Greinacher rectifier / engineering model
Vrf src 0 SIN(0 {amp} {f})
Rsrc src rf 50
Cmatch rf 0 {C}p
Rloss rf rfl {max(1.,2*math.pi*f*L*1e-9/40)}
Lmatch rfl matched {L}n
Cpump matched pump 100p
Lp1 0 d1a .7n
D1 d1a pump SMS
Lp2 pump d2a .7n
D2 d2a out SMS
Cout out 0 100p
Vload out 0 {V}
{MODEL}
.options reltol=0.002 abstol=1p vntol=1u
.tran {1/f/40} {stop} {stop*.8} {1/f/30}
.meas tran iout AVG i(Vload) FROM={stop*.8} TO={stop}
.meas tran pin AVG par('v(rf)*(v(src)-v(rf))/50') FROM={stop*.8} TO={stop}
.end
'''
 path=OUT/(tag+'.cir');path.write_text(deck);r=subprocess.run([NG,'-b',str(path)],capture_output=True,text=True,timeout=30);log=r.stdout+r.stderr;(OUT/(tag+'.log')).write_text(log)
 def get(n):
  mt=re.search(r'^'+n+r'\s*=\s*([-+\d.eE]+)',log,re.M)
  if not mt:raise RuntimeError(log[-1200:])
  return float(mt[1])
 i=get('iout');return dict(dbm=dbm,L_nH=L,C_pF=C,V=V,f=f,stop_s=stop,iout_A=i,pdc_W=V*i,eta=max(0,V*i/power),rf_absorbed_W=get('pin'))
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.add_argument('--freq',type=float,default=2.45e9);ap.add_argument('--folder',default='rectifier');a=ap.parse_args()
 OUT=P/'results'/a.folder;OUT.mkdir(exist_ok=True)
 rows=[]
 for L,C in itertools.product(([3.3,6.8,10,15,22,33] if a.freq>1e9 else [22,33,47,68,100,150]),[.1,.5,1.,2.]):
  row=run(f=a.freq,L=L,C=C,stop=0.6e-6,tag=f'match_{L}_{C}');rows.append(row)
 best=max(rows,key=lambda r:r['pdc_W']);print('Best',best,flush=True)
 (OUT/'matching.json').write_text(json.dumps(rows,indent=2))
 curves=[]
 for dbm,V in itertools.product([-30,-25,-20,-15,-12,-11,-10,-9,-8,-7,-6,-5],[.13,.2,.4,.6,.7]):
  r=run(dbm,f=a.freq,L=best['L_nH'],C=best['C_pF'],V=V,tag=f'p{dbm}_v{V}');curves.append(r)
 (OUT/'sweep.json').write_text(json.dumps(curves,indent=2))
 check=run(-10,f=a.freq,L=best['L_nH'],C=best['C_pF'],V=.2,stop=2e-6,tag='settling_check');(OUT/'settling_check.json').write_text(json.dumps(check,indent=2))
 print('Done',check,flush=True)
