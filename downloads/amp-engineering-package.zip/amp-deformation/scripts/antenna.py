"""Headless EMerge patch coupon; dimensions shared with KiCad generator.
Run from repository root: PYTHONPATH=src python examples/amp-deformation/scripts/antenna.py
"""
import os
os.environ.setdefault('MKL_THREADING_LAYER','GNU')
os.environ.setdefault('OMP_NUM_THREADS','4')
import argparse,json
from pathlib import Path
import numpy as np
import emerge as em
P=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--band',choices=['2450','915','868'],default='2450');p.add_argument('--length',type=float,default=None);p.add_argument('--inset',type=float,default=9.0);p.add_argument('--resolution',type=float,default=.24);p.add_argument('--points',type=int,default=9);p.add_argument('--compact',action='store_true');p.add_argument('--body',action='store_true');p.add_argument('--margin',type=float,default=None);p.add_argument('--tag',default='initial');p.add_argument('--er',type=float,default=4.3);p.add_argument('--board',type=float);p.add_argument('--patch-width',type=float);p.add_argument('--thickness',type=float,default=1.6);p.add_argument('--full-pattern',action='store_true');a=p.parse_args()
mm=.001; low=a.band in ('915','868'); BW,BH=(100.,110.) if low else (70.,60.); W=80. if low else 37.6; L=a.length or (82.8 if a.band=='868' else 78. if low else 29.); a.length=L; cx=BW/2; x0=cx-W/2;y0=10. if low else 12.; yend=BH-5; h=1.6; w=3.05; gap=1.0; margin=a.margin or (100. if low else 50.)
if a.compact:
 BW=BH=49.;cx=24.5;W=38. if low else 37.6;x0=cx-W/2;y0=3. if low else 5.5;yend=44.
if a.band=='868':
 BW=BH=a.board or 120.;W=a.patch_width or 100.;L=a.length or 82.8;cx=BW/2;x0=cx-W/2;y0=8.;yend=BH-5
 a.length=L
h=a.thickness;w=3.05*h/1.6
m=em.Simulation('AMP_patch_'+a.tag)
sub=em.geo.Box(BW*mm,BH*mm,h*mm,position=(0,0,-h*mm)).set_material(em.Material(a.er,tand=.02))
air=em.geo.Box((BW+2*margin)*mm,(BH+2*margin)*mm,(2*margin+10)*mm,position=(-margin*mm,-margin*mm,(-margin-h)*mm)).background()
patch=em.geo.XYPlate(W*mm,L*mm,position=(x0*mm,y0*mm,0))
for x in (cx-w/2-gap,cx+w/2):
 cut=em.geo.XYPlate(gap*mm,a.inset*mm,position=(x*mm,(y0+L-a.inset)*mm,0));patch=em.geo.remove(patch,cut)
line=em.geo.XYPlate(w*mm,(yend-y0-L)*mm,position=((cx-w/2)*mm,(y0+L)*mm,0))
patch=em.geo.add(patch,line).set_material(em.lib.PEC)
ground=em.geo.XYPlate(BW*mm,BH*mm,position=(0,0,-h*mm)).set_material(em.lib.PEC)
port=em.geo.Plate(np.array([(cx-w/2)*mm,yend*mm,-h*mm]),np.array([w*mm,0,0]),np.array([0,0,h*mm]))

if a.body:
 # Homogeneous effective tissue phantom, deliberately simplified; 10 mm spacer.
 em.geo.Box(BW*mm,BH*mm,25*mm,position=(0,0,(-h-10-25)*mm)).set_material(em.Material(38,tand=.30))
m.commit_geometry();m.mw.set_frequency_range(*((.820e9,.916e9,a.points) if a.band=='868' else (.83e9,1.0e9,a.points) if low else (2.25e9,2.65e9,a.points)));m.mw.set_resolution(a.resolution)
m.mesher.set_boundary_size(patch,2.0*mm);m.mesher.set_face_size(port,.8*mm)
m.generate_mesh();m.mw.bc.AbsorbingBoundary(air.boundary());m.mw.bc.LumpedPort(port,1,width=w*mm,height=h*mm,direction=em.ZAX,Z0=50)
d=m.mw.run_sweep();f=np.asarray(d.scalar.grid.freq).ravel();s=np.asarray(d.scalar.grid.S(1,1)).ravel()
out=P/'results';out.mkdir(exist_ok=True)
np.savez(out/(a.tag+'.npz'),frequency_hz=f,s11=s)
with (out/(a.tag+'.s1p')).open('w') as fp:
 fp.write('# Hz S RI R 50\n');fp.writelines(f'{fi:.8g} {si.real:.9g} {si.imag:.9g}\n' for fi,si in zip(f,s))
res=vars(a)|{'geometry_mm':dict(board_w=BW,board_h=BH,patch_w=W,patch_l=L,patch_y=y0,feed_end=yend,inset=a.inset,h=h,wline=w),'frequency_hz':f.tolist(),'s11_db':(20*np.log10(abs(s))).tolist(),'status':'FEM solved; first-order ABC; PEC metal; body='+str(a.body)+'; convergence requires separate comparison'}
try:
 field=d.field.find(freq=float(f[np.argmin(abs(f-868e6))] if a.band=='868' else f[np.argmin(abs(s))]));ff=field.farfield_2d((0,0,1),(1,0,0),air.boundary());np.savez(out/(a.tag+'_pattern.npz'),angle=ff.ang,gain=ff.gain.norm)
 res['pattern_frequency_hz']=float(field.freq);res['peak_gain_cut_dBi']=float(20*np.log10(ff.gain.norm.max()));res['radiated_power_W']=float(ff.Ptot)
 if a.full_pattern:
  sphere=field.farfield_3d(air.boundary(),thetas=np.linspace(0,np.pi,37),phis=np.linspace(-np.pi,np.pi,73))
  np.savez(out/(a.tag+'_sphere.npz'),theta=sphere.theta,phi=sphere.phi,gain=sphere.gain.norm)
  res['peak_realized_gain_dBi']=float(20*np.log10(sphere.gain.norm.max()))
  res['radiation_efficiency_estimate']=float(sphere.Ptot/(1-abs(s[np.argmin(abs(f-float(field.freq)))])**2))
except Exception as e:res['farfield_error']=str(e)
(out/(a.tag+'.json')).write_text(json.dumps(res,indent=2))
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.plot(f/1e9,20*np.log10(abs(s)),'o-');plt.axhline(-10,color='gray',ls='--');plt.axvspan(*((.863,.870) if a.band=='868' else (.902,.928) if low else (2.4,2.4835)),alpha=.15);plt.xlabel('Frequency (GHz)');plt.ylabel('S11 (dB)');plt.grid();plt.tight_layout();plt.savefig(out/(a.tag+'.png'),dpi=180)
print(json.dumps(res))
